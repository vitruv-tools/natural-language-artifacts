/**
 */
package tools.vitruv.change.atomic.eobject.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import tools.vitruv.change.atomic.AdditiveEChange;
import tools.vitruv.change.atomic.EChange;
import tools.vitruv.change.atomic.SubtractiveEChange;

import tools.vitruv.change.atomic.eobject.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see tools.vitruv.change.atomic.eobject.EobjectPackage
 * @generated
 */
public class EobjectSwitch<T> extends Switch<T>
{
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static EobjectPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EobjectSwitch()
	{
		if (modelPackage == null)
		{
			modelPackage = EobjectPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage)
	{
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject)
	{
		switch (classifierID)
		{
			case EobjectPackage.EOBJECT_ADDED_ECHANGE:
			{
				EObjectAddedEChange<?> eObjectAddedEChange = (EObjectAddedEChange<?>)theEObject;
				T result = caseEObjectAddedEChange(eObjectAddedEChange);
				if (result == null) result = caseAdditiveEChange(eObjectAddedEChange);
				if (result == null) result = caseEChange(eObjectAddedEChange);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case EobjectPackage.EOBJECT_SUBTRACTED_ECHANGE:
			{
				EObjectSubtractedEChange<?> eObjectSubtractedEChange = (EObjectSubtractedEChange<?>)theEObject;
				T result = caseEObjectSubtractedEChange(eObjectSubtractedEChange);
				if (result == null) result = caseSubtractiveEChange(eObjectSubtractedEChange);
				if (result == null) result = caseEChange(eObjectSubtractedEChange);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case EobjectPackage.EOBJECT_EXISTENCE_ECHANGE:
			{
				EObjectExistenceEChange<?> eObjectExistenceEChange = (EObjectExistenceEChange<?>)theEObject;
				T result = caseEObjectExistenceEChange(eObjectExistenceEChange);
				if (result == null) result = caseEChange(eObjectExistenceEChange);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case EobjectPackage.CREATE_EOBJECT:
			{
				CreateEObject<?> createEObject = (CreateEObject<?>)theEObject;
				T result = caseCreateEObject(createEObject);
				if (result == null) result = caseEObjectExistenceEChange(createEObject);
				if (result == null) result = caseEChange(createEObject);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case EobjectPackage.DELETE_EOBJECT:
			{
				DeleteEObject<?> deleteEObject = (DeleteEObject<?>)theEObject;
				T result = caseDeleteEObject(deleteEObject);
				if (result == null) result = caseEObjectExistenceEChange(deleteEObject);
				if (result == null) result = caseEChange(deleteEObject);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject Added EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject Added EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object> T caseEObjectAddedEChange(EObjectAddedEChange<Element> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject Subtracted EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject Subtracted EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object> T caseEObjectSubtractedEChange(EObjectSubtractedEChange<Element> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject Existence EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject Existence EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object> T caseEObjectExistenceEChange(EObjectExistenceEChange<Element> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Create EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Create EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object> T caseCreateEObject(CreateEObject<Element> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Delete EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Delete EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object> T caseDeleteEObject(DeleteEObject<Element> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object> T caseEChange(EChange<Element> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Additive EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Additive EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object, Value extends Object> T caseAdditiveEChange(AdditiveEChange<Element, Value> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Subtractive EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Subtractive EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object, Value extends Object> T caseSubtractiveEChange(SubtractiveEChange<Element, Value> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object)
	{
		return null;
	}

} //EobjectSwitch
