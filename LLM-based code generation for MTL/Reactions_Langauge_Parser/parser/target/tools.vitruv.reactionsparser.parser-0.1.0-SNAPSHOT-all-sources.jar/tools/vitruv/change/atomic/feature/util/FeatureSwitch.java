/**
 */
package tools.vitruv.change.atomic.feature.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.util.Switch;

import tools.vitruv.change.atomic.EChange;

import tools.vitruv.change.atomic.feature.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see tools.vitruv.change.atomic.feature.FeaturePackage
 * @generated
 */
public class FeatureSwitch<T> extends Switch<T>
{
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static FeaturePackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FeatureSwitch()
	{
		if (modelPackage == null)
		{
			modelPackage = FeaturePackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage)
	{
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject)
	{
		switch (classifierID)
		{
			case FeaturePackage.FEATURE_ECHANGE:
			{
				FeatureEChange<?, ?> featureEChange = (FeatureEChange<?, ?>)theEObject;
				T result = caseFeatureEChange(featureEChange);
				if (result == null) result = caseEChange(featureEChange);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case FeaturePackage.UPDATE_MULTI_VALUED_FEATURE_ECHANGE:
			{
				UpdateMultiValuedFeatureEChange<?, ?> updateMultiValuedFeatureEChange = (UpdateMultiValuedFeatureEChange<?, ?>)theEObject;
				T result = caseUpdateMultiValuedFeatureEChange(updateMultiValuedFeatureEChange);
				if (result == null) result = caseFeatureEChange(updateMultiValuedFeatureEChange);
				if (result == null) result = caseEChange(updateMultiValuedFeatureEChange);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case FeaturePackage.UPDATE_SINGLE_VALUED_FEATURE_ECHANGE:
			{
				UpdateSingleValuedFeatureEChange<?, ?> updateSingleValuedFeatureEChange = (UpdateSingleValuedFeatureEChange<?, ?>)theEObject;
				T result = caseUpdateSingleValuedFeatureEChange(updateSingleValuedFeatureEChange);
				if (result == null) result = caseFeatureEChange(updateSingleValuedFeatureEChange);
				if (result == null) result = caseEChange(updateSingleValuedFeatureEChange);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case FeaturePackage.UNSET_FEATURE:
			{
				UnsetFeature<?, ?> unsetFeature = (UnsetFeature<?, ?>)theEObject;
				T result = caseUnsetFeature(unsetFeature);
				if (result == null) result = caseFeatureEChange(unsetFeature);
				if (result == null) result = caseEChange(unsetFeature);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object, Feature extends EStructuralFeature> T caseFeatureEChange(FeatureEChange<Element, Feature> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Update Multi Valued Feature EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Update Multi Valued Feature EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object, Feature extends EStructuralFeature> T caseUpdateMultiValuedFeatureEChange(UpdateMultiValuedFeatureEChange<Element, Feature> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Update Single Valued Feature EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Update Single Valued Feature EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object, Feature extends EStructuralFeature> T caseUpdateSingleValuedFeatureEChange(UpdateSingleValuedFeatureEChange<Element, Feature> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Unset Feature</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Unset Feature</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object, Feature extends EStructuralFeature> T caseUnsetFeature(UnsetFeature<Element, Feature> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EChange</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EChange</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public <Element extends Object> T caseEChange(EChange<Element> object)
	{
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object)
	{
		return null;
	}

} //FeatureSwitch
