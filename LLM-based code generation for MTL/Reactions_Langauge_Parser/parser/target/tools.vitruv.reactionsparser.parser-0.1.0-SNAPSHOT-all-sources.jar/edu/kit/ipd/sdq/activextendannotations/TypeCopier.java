package edu.kit.ipd.sdq.activextendannotations;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import org.eclipse.xtend.lib.annotations.FinalFieldsConstructor;
import org.eclipse.xtend.lib.macro.TransformationContext;
import org.eclipse.xtend.lib.macro.declaration.MutableMethodDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableTypeParameterDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableTypeParameterDeclarator;
import org.eclipse.xtend.lib.macro.declaration.ResolvedMethod;
import org.eclipse.xtend.lib.macro.declaration.ResolvedTypeParameter;
import org.eclipse.xtend.lib.macro.declaration.Type;
import org.eclipse.xtend.lib.macro.declaration.TypeParameterDeclaration;
import org.eclipse.xtend.lib.macro.declaration.TypeParameterDeclarator;
import org.eclipse.xtend.lib.macro.declaration.TypeReference;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;

/**
 * Helper to copy types from one Java element to another. Copying types is
 * straightforward a long as no type parameters are involved. However,
 * <em>if</em> type parameters are involved, they need to be copied and any
 * reference to a type parameter needs to be replaced with its copy. This is
 * handled by this class.
 * 
 * <p>A new instance of this class must be created for every element types are
 * to be copied to. If there is a parent scope from which type parameters could
 * be inherited, the copier for the parent scope must be passed in as parent.
 */
@FinalFieldsConstructor
@SuppressWarnings("all")
public class TypeCopier {
  private final HashMap<TypeReference, TypeReference> typeParameterMappings = new HashMap<TypeReference, TypeReference>();

  @Extension
  private final TransformationContext context;

  public TypeCopier(final TypeCopier parent, final TransformationContext context) {
    this(context);
    this.typeParameterMappings.putAll(parent.typeParameterMappings);
  }

  /**
   * Copies all type parameters that appear in the {@code source} type reference to
   * the {@code target} type declaration. Afterwards, this copier can be used to replace
   * type parameters that come from {@code source} and are used in {@code target}.
   */
  public void copyTypeParametersFrom(final MutableTypeParameterDeclarator target, final TypeReference source) {
    final Type sourceType = source.getType();
    if ((sourceType instanceof TypeParameterDeclarator)) {
      final Iterator<TypeReference> actualTypeParameters = source.getActualTypeArguments().iterator();
      final Consumer<TypeParameterDeclaration> _function = (TypeParameterDeclaration param) -> {
        boolean _containsKey = this.typeParameterMappings.containsKey(param);
        boolean _not = (!_containsKey);
        if (_not) {
          final MutableTypeParameterDeclaration copy = target.addTypeParameter(param.getSimpleName(), ((TypeReference[])Conversions.unwrapArray(param.getUpperBounds(), TypeReference.class)));
          this.typeParameterMappings.put(this.context.newTypeReference(param), this.context.newTypeReference(copy));
          final Function1<TypeReference, TypeReference> _function_1 = (TypeReference it) -> {
            return this.replaceTypeParameters(it);
          };
          copy.setUpperBounds(IterableExtensions.map(copy.getUpperBounds(), _function_1));
        }
      };
      this.getAllReferencedTypeVariables(source).forEach(_function);
      final Consumer<TypeParameterDeclaration> _function_1 = (TypeParameterDeclaration param) -> {
        final TypeReference actualType = actualTypeParameters.next();
        this.typeParameterMappings.put(this.context.newTypeReference(param), this.replaceTypeParameters(actualType));
      };
      ((TypeParameterDeclarator)sourceType).getTypeParameters().forEach(_function_1);
    }
  }

  /**
   * Copies all type parameters from the {@code source} method to the
   * {@code target} method. Afterwards, this copier can be used to replace
   * type parameters that come from {@code source} and are used in {@code target}.
   */
  public void copyTypeParametersFrom(final MutableMethodDeclaration target, final ResolvedMethod source) {
    final Consumer<ResolvedTypeParameter> _function = (ResolvedTypeParameter param) -> {
      final MutableTypeParameterDeclaration copy = target.addTypeParameter(param.getDeclaration().getSimpleName(), ((TypeReference[])Conversions.unwrapArray(param.getResolvedUpperBounds(), TypeReference.class)));
      this.typeParameterMappings.put(this.context.newTypeReference(param.getDeclaration()), this.context.newTypeReference(copy));
      final Function1<TypeReference, TypeReference> _function_1 = (TypeReference it) -> {
        return this.replaceTypeParameters(it);
      };
      copy.setUpperBounds(IterableExtensions.map(copy.getUpperBounds(), _function_1));
    };
    source.getResolvedTypeParameters().forEach(_function);
  }

  /**
   * Copies all type parameters from the {@code source} method to the
   * {@code target} method. Afterwards, this copier can be used to replace
   * type parameters that come from {@code source} and are used in {@code target}.
   */
  public void copyTypeParametersFrom(final MutableMethodDeclaration target, final MutableMethodDeclaration source) {
    final Consumer<MutableTypeParameterDeclaration> _function = (MutableTypeParameterDeclaration param) -> {
      final MutableTypeParameterDeclaration copy = target.addTypeParameter(param.getSimpleName(), ((TypeReference[])Conversions.unwrapArray(param.getUpperBounds(), TypeReference.class)));
      this.typeParameterMappings.put(this.context.newTypeReference(param), this.context.newTypeReference(copy));
      final Function1<TypeReference, TypeReference> _function_1 = (TypeReference it) -> {
        return this.replaceTypeParameters(it);
      };
      copy.setUpperBounds(IterableExtensions.map(copy.getUpperBounds(), _function_1));
    };
    source.getTypeParameters().forEach(_function);
  }

  /**
   * Replaces references to type parameters by their copies, which were
   * created by calling {@link copyTypeParametersFrom}. If
   * {@link copyTypeParametersFrom} was not called or the {@code source} it
   * was called with does not contain type parameters, the type reference
   * will be returned unchanged.
   * 
   * @param target The type reference to replace type parameters in.
   * @return An equal type reference that has all references to type
   * 		parameters replaced by their according copies.
   */
  public TypeReference replaceTypeParameters(final TypeReference target) {
    final Function2<TypeReference, Map.Entry<TypeReference, TypeReference>, TypeReference> _function = (TypeReference result, Map.Entry<TypeReference, TypeReference> mapping) -> {
      return this.replace(result, mapping.getKey(), mapping.getValue());
    };
    return IterableExtensions.<Map.Entry<TypeReference, TypeReference>, TypeReference>fold(this.typeParameterMappings.entrySet(), target, _function);
  }

  private TypeReference replace(final TypeReference target, final TypeReference oldType, final TypeReference newType) {
    boolean _equals = Objects.equal(target, oldType);
    if (_equals) {
      return newType;
    }
    boolean _isEmpty = target.getActualTypeArguments().isEmpty();
    boolean _not = (!_isEmpty);
    if (_not) {
      Type _type = target.getType();
      boolean _tripleNotEquals = (_type != null);
      if (_tripleNotEquals) {
        final Function1<TypeReference, TypeReference> _function = (TypeReference it) -> {
          return this.replace(it, oldType, newType);
        };
        return this.context.newTypeReference(target.getType(), ((TypeReference[])Conversions.unwrapArray(ListExtensions.<TypeReference, TypeReference>map(target.getActualTypeArguments(), _function), TypeReference.class)));
      }
    }
    boolean _isWildCard = target.isWildCard();
    if (_isWildCard) {
      TypeReference _upperBound = target.getUpperBound();
      TypeReference _object = this.context.getObject();
      boolean _notEquals = (!Objects.equal(_upperBound, _object));
      if (_notEquals) {
        return this.context.newWildcardTypeReference(this.replace(target.getUpperBound(), oldType, newType));
      } else {
        boolean _isAnyType = target.getLowerBound().isAnyType();
        boolean _not_1 = (!_isAnyType);
        if (_not_1) {
          return this.context.newWildcardTypeReferenceWithLowerBound(this.replace(target.getLowerBound(), oldType, newType));
        }
      }
    }
    boolean _isArray = target.isArray();
    if (_isArray) {
      return this.context.newArrayTypeReference(this.replace(target.getArrayComponentType(), oldType, newType));
    }
    return target;
  }

  private Iterable<TypeParameterDeclaration> getAllReferencedTypeVariables(final TypeReference source) {
    Iterable<TypeParameterDeclaration> _xblockexpression = null;
    {
      final Type sourceType = source.getType();
      Iterable<TypeParameterDeclaration> _xifexpression = null;
      if ((sourceType instanceof TypeParameterDeclaration)) {
        _xifexpression = List.<TypeParameterDeclaration>of(((TypeParameterDeclaration)sourceType));
      } else {
        Iterable<TypeParameterDeclaration> _xifexpression_1 = null;
        boolean _isWildCard = source.isWildCard();
        if (_isWildCard) {
          Iterable<TypeParameterDeclaration> _xifexpression_2 = null;
          TypeReference _upperBound = source.getUpperBound();
          TypeReference _object = this.context.getObject();
          boolean _notEquals = (!Objects.equal(_upperBound, _object));
          if (_notEquals) {
            _xifexpression_2 = this.getAllReferencedTypeVariables(source.getUpperBound());
          } else {
            _xifexpression_2 = CollectionLiterals.<TypeParameterDeclaration>emptyList();
          }
          Iterable<TypeParameterDeclaration> _xifexpression_3 = null;
          boolean _isAnyType = source.getLowerBound().isAnyType();
          boolean _not = (!_isAnyType);
          if (_not) {
            _xifexpression_3 = this.getAllReferencedTypeVariables(source.getLowerBound());
          } else {
            _xifexpression_3 = CollectionLiterals.<TypeParameterDeclaration>emptyList();
          }
          _xifexpression_1 = Iterables.<TypeParameterDeclaration>concat(_xifexpression_2, _xifexpression_3);
        } else {
          Iterable<TypeParameterDeclaration> _xifexpression_4 = null;
          boolean _isArray = source.isArray();
          if (_isArray) {
            _xifexpression_4 = this.getAllReferencedTypeVariables(source.getArrayComponentType());
          } else {
            final Function1<TypeReference, Iterable<TypeParameterDeclaration>> _function = (TypeReference it) -> {
              return this.getAllReferencedTypeVariables(it);
            };
            _xifexpression_4 = IterableExtensions.<TypeReference, TypeParameterDeclaration>flatMap(source.getActualTypeArguments(), _function);
          }
          _xifexpression_1 = _xifexpression_4;
        }
        _xifexpression = _xifexpression_1;
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }

  public TypeCopier(final TransformationContext context) {
    super();
    this.context = context;
  }
}
