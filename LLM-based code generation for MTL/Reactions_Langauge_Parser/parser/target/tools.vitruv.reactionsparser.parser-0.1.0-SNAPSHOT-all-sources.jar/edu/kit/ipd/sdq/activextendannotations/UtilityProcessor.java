package edu.kit.ipd.sdq.activextendannotations;

import com.google.common.base.Objects;
import java.util.List;
import java.util.function.Consumer;
import org.eclipse.xtend.lib.macro.TransformationContext;
import org.eclipse.xtend.lib.macro.TransformationParticipant;
import org.eclipse.xtend.lib.macro.ValidationContext;
import org.eclipse.xtend.lib.macro.ValidationParticipant;
import org.eclipse.xtend.lib.macro.declaration.MutableClassDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableConstructorDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableFieldDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableMethodDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableTypeDeclaration;
import org.eclipse.xtend.lib.macro.declaration.Visibility;
import org.eclipse.xtend2.lib.StringConcatenationClient;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class UtilityProcessor implements TransformationParticipant<MutableTypeDeclaration>, ValidationParticipant<MutableTypeDeclaration> {
  @Override
  public void doTransform(final List<? extends MutableTypeDeclaration> annotatedTargetElements, @Extension final TransformationContext context) {
    for (final MutableTypeDeclaration annotatedType : annotatedTargetElements) {
      if ((annotatedType instanceof MutableClassDeclaration)) {
        ((MutableClassDeclaration)annotatedType).setFinal(true);
        final Function1<MutableConstructorDeclaration, Boolean> _function = (MutableConstructorDeclaration it) -> {
          return Boolean.valueOf((Objects.equal(it.getVisibility(), Visibility.PRIVATE) && (((Object[])Conversions.unwrapArray(it.getParameters(), Object.class)).length == 0)));
        };
        final Iterable<? extends MutableConstructorDeclaration> privateParameterlessConstructors = IterableExtensions.filter(((MutableClassDeclaration)annotatedType).getDeclaredConstructors(), _function);
        int _length = ((Object[])Conversions.unwrapArray(privateParameterlessConstructors, Object.class)).length;
        boolean _equals = (_length == 0);
        if (_equals) {
          final Procedure1<MutableConstructorDeclaration> _function_1 = (MutableConstructorDeclaration it) -> {
            it.setVisibility(Visibility.PRIVATE);
            StringConcatenationClient _client = new StringConcatenationClient() {
              @Override
              protected void appendTo(StringConcatenationClient.TargetStringConcatenation _builder) {
              }
            };
            it.setBody(_client);
          };
          ((MutableClassDeclaration)annotatedType).addConstructor(_function_1);
        }
      }
    }
  }

  @Override
  public void doValidate(final List<? extends MutableTypeDeclaration> annotatedTargetElements, @Extension final ValidationContext context) {
    for (final MutableTypeDeclaration annotatedType : annotatedTargetElements) {
      if ((annotatedType instanceof MutableClassDeclaration)) {
        final Function1<MutableConstructorDeclaration, Boolean> _function = (MutableConstructorDeclaration it) -> {
          return Boolean.valueOf(((!Objects.equal(it.getVisibility(), Visibility.PRIVATE)) || (((Object[])Conversions.unwrapArray(it.getParameters(), Object.class)).length > 0)));
        };
        final Consumer<MutableConstructorDeclaration> _function_1 = (MutableConstructorDeclaration it) -> {
          context.addError(it, ("A Utility class may only have a private, parameterless constructor " + 
            "(which is added automatically)."));
        };
        IterableExtensions.filter(((MutableClassDeclaration)annotatedType).getDeclaredConstructors(), _function).forEach(_function_1);
        final Function1<MutableMethodDeclaration, Boolean> _function_2 = (MutableMethodDeclaration it) -> {
          boolean _isStatic = it.isStatic();
          return Boolean.valueOf((!_isStatic));
        };
        final Consumer<MutableMethodDeclaration> _function_3 = (MutableMethodDeclaration it) -> {
          context.addError(it, "A Utility class may only have static methods.");
        };
        IterableExtensions.filter(((MutableClassDeclaration)annotatedType).getDeclaredMethods(), _function_2).forEach(_function_3);
        final Function1<MutableFieldDeclaration, Boolean> _function_4 = (MutableFieldDeclaration it) -> {
          boolean _isStatic = it.isStatic();
          return Boolean.valueOf((!_isStatic));
        };
        final Consumer<MutableFieldDeclaration> _function_5 = (MutableFieldDeclaration it) -> {
          context.addError(it, "A Utility class must not have instance fields, as it is never constructed");
        };
        IterableExtensions.filter(((MutableClassDeclaration)annotatedType).getDeclaredFields(), _function_4).forEach(_function_5);
        final Function1<MutableFieldDeclaration, Boolean> _function_6 = (MutableFieldDeclaration it) -> {
          return Boolean.valueOf(it.isStatic());
        };
        final Function1<MutableFieldDeclaration, Boolean> _function_7 = (MutableFieldDeclaration it) -> {
          boolean _isFinal = it.isFinal();
          return Boolean.valueOf((!_isFinal));
        };
        final Consumer<MutableFieldDeclaration> _function_8 = (MutableFieldDeclaration it) -> {
          context.addError(it, "A Utility class may only have final static fields, as it must not store state.");
        };
        IterableExtensions.filter(IterableExtensions.filter(((MutableClassDeclaration)annotatedType).getDeclaredFields(), _function_6), _function_7).forEach(_function_8);
      } else {
        context.addError(annotatedType, "Only classes can be declared as Utility");
      }
    }
  }
}
