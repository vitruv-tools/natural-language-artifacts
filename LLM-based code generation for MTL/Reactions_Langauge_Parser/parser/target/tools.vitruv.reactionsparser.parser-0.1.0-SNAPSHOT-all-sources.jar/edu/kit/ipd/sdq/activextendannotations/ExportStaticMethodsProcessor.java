package edu.kit.ipd.sdq.activextendannotations;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import org.eclipse.xtend.lib.annotations.FinalFieldsConstructor;
import org.eclipse.xtend.lib.macro.TransformationContext;
import org.eclipse.xtend.lib.macro.TransformationParticipant;
import org.eclipse.xtend.lib.macro.declaration.AnnotationReference;
import org.eclipse.xtend.lib.macro.declaration.AnnotationTarget;
import org.eclipse.xtend.lib.macro.declaration.AnnotationTypeDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MemberDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MethodDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableMethodDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableTypeDeclaration;
import org.eclipse.xtend.lib.macro.declaration.NamedElement;
import org.eclipse.xtend.lib.macro.declaration.ParameterDeclaration;
import org.eclipse.xtend.lib.macro.declaration.ResolvedMethod;
import org.eclipse.xtend.lib.macro.declaration.ResolvedParameter;
import org.eclipse.xtend.lib.macro.declaration.Type;
import org.eclipse.xtend.lib.macro.declaration.TypeDeclaration;
import org.eclipse.xtend.lib.macro.declaration.TypeReference;
import org.eclipse.xtend.lib.macro.expression.Expression;
import org.eclipse.xtend.lib.macro.services.AnnotationReferenceBuildContext;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtend2.lib.StringConcatenationClient;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Inline;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class ExportStaticMethodsProcessor implements TransformationParticipant<MutableTypeDeclaration> {
  /**
   * Trick class to have the extension {@link #context}
   */
  @FinalFieldsConstructor
  private static class ContexedProcessor {
    @Extension
    private final TransformationContext context;

    private void doTransform(final MutableTypeDeclaration annotatedType, final AnnotationReference annotation) {
      final Visibility exportedVisiblity = Visibility.valueOf(annotation.getEnumValue("visibility").getSimpleName());
      Collection<TypeReference> _withoutDuplicateTypes = this.withoutDuplicateTypes(this.delegationTargets(annotation));
      for (final TypeReference sourceType : _withoutDuplicateTypes) {
        {
          final Function1<ResolvedMethod, Boolean> _function = (ResolvedMethod it) -> {
            return Boolean.valueOf((it.getDeclaration().isStatic() && this.isAccessibleFrom(it.getDeclaration(), annotatedType)));
          };
          final Iterable<? extends ResolvedMethod> staticMethods = IterableExtensions.filter(sourceType.getDeclaredResolvedMethods(), _function);
          for (final ResolvedMethod staticMethod : staticMethods) {
            final Procedure1<MutableMethodDeclaration> _function_1 = (MutableMethodDeclaration it) -> {
              it.setVisibility(VisibilityExtension.toXtendVisibility(exportedVisiblity, staticMethod.getDeclaration().getVisibility()));
            };
            this.createDelegationTo(annotatedType, staticMethod, _function_1);
          }
        }
      }
    }

    /**
     * Creates a static delegation method to the provided `resolvedMethod`
     * in the provided `type`. The created method will have similar
     * properties as the delegated method, it will for example have the
     * same comment.
     */
    private MutableMethodDeclaration createDelegationTo(final MutableTypeDeclaration target, final ResolvedMethod resolvedMethod, final Procedure1<MutableMethodDeclaration> furtherInitialiser) {
      MutableMethodDeclaration _xblockexpression = null;
      {
        final MethodDeclaration method = resolvedMethod.getDeclaration();
        @Extension
        final TypeCopier typeCopier = new TypeCopier(this.context);
        final Procedure1<MutableMethodDeclaration> _function = (MutableMethodDeclaration it) -> {
          typeCopier.copyTypeParametersFrom(it, resolvedMethod);
          this.context.setPrimarySourceElement(it, method.getDeclaringType());
          it.setReturnType(typeCopier.replaceTypeParameters(resolvedMethod.getResolvedReturnType()));
          it.setVarArgs(method.isVarArgs());
          it.setDocComment(method.getDocComment());
          it.setStatic(true);
          it.setAbstract(false);
          StringConcatenationClient _client = new StringConcatenationClient() {
            @Override
            protected void appendTo(StringConcatenationClient.TargetStringConcatenation _builder) {
              {
                boolean _isVoid = method.getReturnType().isVoid();
                boolean _not = (!_isVoid);
                if (_not) {
                  _builder.append("return ");
                }
              }
              TypeDeclaration _declaringType = method.getDeclaringType();
              _builder.append(_declaringType);
              _builder.append(".");
              String _simpleName = method.getSimpleName();
              _builder.append(_simpleName);
              _builder.append("(");
              final Function1<ParameterDeclaration, CharSequence> _function = (ParameterDeclaration it_1) -> {
                return it_1.getSimpleName();
              };
              String _join = IterableExtensions.join(method.getParameters(), ", ", _function);
              _builder.append(_join);
              _builder.append(");");
              _builder.newLineIfNotEmpty();
            }
          };
          it.setBody(_client);
        };
        final MutableMethodDeclaration copy = target.addMethod(method.getSimpleName(), _function);
        final Consumer<AnnotationReference> _function_1 = (AnnotationReference it) -> {
          copy.addAnnotation(it);
        };
        method.getAnnotations().forEach(_function_1);
        final Consumer<ResolvedParameter> _function_2 = (ResolvedParameter it) -> {
          copy.addParameter(it.getDeclaration().getSimpleName(), typeCopier.replaceTypeParameters(it.getResolvedType()));
        };
        resolvedMethod.getResolvedParameters().forEach(_function_2);
        furtherInitialiser.apply(copy);
        boolean _isAsVisibleAsAs = this.isAsVisibleAsAs(method, copy);
        if (_isAsVisibleAsAs) {
          final int parametersLength = ((Object[])Conversions.unwrapArray(method.getParameters(), Object.class)).length;
          final Procedure1<AnnotationReferenceBuildContext> _function_3 = (AnnotationReferenceBuildContext it) -> {
            StringConcatenation _builder = new StringConcatenation();
            _builder.append("$");
            _builder.append((parametersLength + 1));
            _builder.append(".");
            String _simpleName = method.getSimpleName();
            _builder.append(_simpleName);
            _builder.append("(");
            {
              IntegerRange _upTo = new IntegerRange(1, parametersLength);
              boolean _hasElements = false;
              for(final Integer i : _upTo) {
                if (!_hasElements) {
                  _hasElements = true;
                } else {
                  _builder.appendImmediate(", ", "");
                }
                _builder.append("$");
                _builder.append(i);
              }
            }
            _builder.append(")");
            it.setStringValue(
              "value", _builder.toString());
            it.setClassValue("imported", this.context.newTypeReference(method.getDeclaringType()));
          };
          copy.addAnnotation(this.context.newAnnotationReference(Inline.class, _function_3));
        }
        _xblockexpression = copy;
      }
      return _xblockexpression;
    }

    /**
     * Filters the provided type references, such that there is only on reference per type in the result.
     * 
     * @param references The references to process.
     * @return A copy of the provided `references`, such that any reference referencing a type referenced by another reference is removed.
     */
    private Collection<TypeReference> withoutDuplicateTypes(final TypeReference[] references) {
      Collection<TypeReference> _xblockexpression = null;
      {
        final HashMap<Type, TypeReference> typeToRef = CollectionLiterals.<Type, TypeReference>newHashMap();
        final Consumer<TypeReference> _function = (TypeReference it) -> {
          typeToRef.put(it.getType(), it);
        };
        ((List<TypeReference>)Conversions.doWrapArray(references)).forEach(_function);
        _xblockexpression = typeToRef.values();
      }
      return _xblockexpression;
    }

    /**
     * Checks if any of the provided annotations reference the same type.
     * If so, adds an error to those annotations and filters them out of
     * the result.
     * 
     * Additionally adds a warning if an annotation references the same
     * type in itself, but does not filter it out.
     * 
     * @param annotations The {@link StaticDelegate} annotations to check
     * @return The annotations that did not declare types that other
     * annotations also declared
     */
    private ArrayList<AnnotationReference> checkForDuplicateTypes(final Iterable<? extends AnnotationReference> annotations) {
      ArrayList<AnnotationReference> _xblockexpression = null;
      {
        int _length = ((Object[])Conversions.unwrapArray(annotations, Object.class)).length;
        final ArrayList<AnnotationReference> validAnnotations = new ArrayList<AnnotationReference>(_length);
        final HashMap<Type, Set<AnnotationReference>> usedTypes = new HashMap<Type, Set<AnnotationReference>>();
        for (final AnnotationReference annotation : annotations) {
          {
            final Function1<TypeReference, Type> _function = (TypeReference it) -> {
              return it.getType();
            };
            final HashSet<Type> containedDuplicates = ExportStaticMethodsProcessor.ContexedProcessor.<Type>duplicates(ListExtensions.<TypeReference, Type>map(((List<TypeReference>)Conversions.doWrapArray(this.delegationTargets(annotation))), _function));
            int _length_1 = ((Object[])Conversions.unwrapArray(containedDuplicates, Object.class)).length;
            boolean _greaterThan = (_length_1 > 0);
            if (_greaterThan) {
              final Consumer<Type> _function_1 = (Type it) -> {
                Expression _delegationTargetsExpression = this.delegationTargetsExpression(annotation);
                StringConcatenation _builder = new StringConcatenation();
                _builder.append("Type ");
                String _simpleName = it.getSimpleName();
                _builder.append(_simpleName);
                _builder.append(" is listet multiple times.");
                this.context.addWarning(_delegationTargetsExpression, _builder.toString());
              };
              containedDuplicates.forEach(_function_1);
            }
            final Function1<TypeReference, Type> _function_2 = (TypeReference it) -> {
              return it.getType();
            };
            List<Type> _map = ListExtensions.<TypeReference, Type>map(((List<TypeReference>)Conversions.doWrapArray(this.delegationTargets(annotation))), _function_2);
            final HashSet<Type> annotatedTypes = new HashSet<Type>(_map);
            final HashSet<Type> duplicates = ExportStaticMethodsProcessor.ContexedProcessor.<Type>intersect(usedTypes.keySet(), annotatedTypes);
            int _length_2 = ((Object[])Conversions.unwrapArray(duplicates, Object.class)).length;
            boolean _equals = (_length_2 == 0);
            if (_equals) {
              validAnnotations.add(annotation);
            } else {
              final Consumer<Type> _function_3 = (Type type) -> {
                Set<AnnotationReference> _get = usedTypes.get(type);
                final Function1<AnnotationReference, Expression> _function_4 = (AnnotationReference it) -> {
                  return this.delegationTargetsExpression(it);
                };
                final Consumer<Expression> _function_5 = (Expression it) -> {
                  StringConcatenation _builder = new StringConcatenation();
                  _builder.append("The type ");
                  String _simpleName = type.getSimpleName();
                  _builder.append(_simpleName);
                  _builder.append(" is also used in another @");
                  String _simpleName_1 = StaticDelegate.class.getSimpleName();
                  _builder.append(_simpleName_1);
                  _builder.append(" annotation.");
                  this.context.addError(it, _builder.toString());
                };
                IterableExtensions.<AnnotationReference, Expression>map(Iterables.<AnnotationReference>concat(_get, Collections.<AnnotationReference>unmodifiableList(CollectionLiterals.<AnnotationReference>newArrayList(annotation))), _function_4).forEach(_function_5);
              };
              duplicates.forEach(_function_3);
            }
            final Consumer<Type> _function_4 = (Type type) -> {
              final BiFunction<Type, Set<AnnotationReference>, Set<AnnotationReference>> _function_5 = (Type k, Set<AnnotationReference> set) -> {
                Set<AnnotationReference> _xblockexpression_1 = null;
                {
                  set.add(annotation);
                  _xblockexpression_1 = set;
                }
                return _xblockexpression_1;
              };
              usedTypes.computeIfPresent(type, _function_5);
              HashSet<AnnotationReference> _hashSet = new HashSet<AnnotationReference>(Collections.<AnnotationReference>unmodifiableList(CollectionLiterals.<AnnotationReference>newArrayList(annotation)));
              usedTypes.putIfAbsent(type, _hashSet);
            };
            annotatedTypes.forEach(_function_4);
          }
        }
        _xblockexpression = validAnnotations;
      }
      return _xblockexpression;
    }

    private ArrayList<AnnotationReference> checkForSelfReference(final Iterable<? extends AnnotationReference> annotations, final MutableTypeDeclaration annotatedType) {
      ArrayList<AnnotationReference> _xblockexpression = null;
      {
        int _length = ((Object[])Conversions.unwrapArray(annotations, Object.class)).length;
        final ArrayList<AnnotationReference> validAnnotations = new ArrayList<AnnotationReference>(_length);
        for (final AnnotationReference annotation : annotations) {
          final Function1<TypeReference, Type> _function = (TypeReference it) -> {
            return it.getType();
          };
          boolean _contains = ListExtensions.<TypeReference, Type>map(((List<TypeReference>)Conversions.doWrapArray(this.delegationTargets(annotation))), _function).contains(annotatedType);
          if (_contains) {
            Expression _expression = annotation.getExpression("value");
            StringConcatenation _builder = new StringConcatenation();
            _builder.append("A type cannot export its own methods. Remove the type ");
            String _simpleName = annotatedType.getSimpleName();
            _builder.append(_simpleName);
            _builder.append(" from the list.");
            this.context.addError(_expression, _builder.toString());
          } else {
            validAnnotations.add(annotation);
          }
        }
        _xblockexpression = validAnnotations;
      }
      return _xblockexpression;
    }

    /**
     * Finds the duplicate entries in the provided `iterable`.
     * 
     * @param iterable The iterable to inspect
     * @return The set of elements present at least twice in the provided
     * `iterable`. Equality is checked based on {@link Object#equals}.
     */
    private static <T extends Object> HashSet<T> duplicates(final Iterable<T> iterable) {
      HashSet<T> _xblockexpression = null;
      {
        int _length = ((Object[])Conversions.unwrapArray(iterable, Object.class)).length;
        final HashSet<T> seen = new HashSet<T>(_length);
        final HashSet<T> duplicates = new HashSet<T>();
        for (final T value : iterable) {
          boolean _contains = seen.contains(value);
          if (_contains) {
            duplicates.add(value);
          } else {
            seen.add(value);
          }
        }
        _xblockexpression = duplicates;
      }
      return _xblockexpression;
    }

    /**
     * @return The instersection of `a` and `b` in a new set.
     */
    private static <T extends Object> HashSet<T> intersect(final Set<T> a, final Set<T> b) {
      HashSet<T> _xblockexpression = null;
      {
        final HashSet<T> copyOfA = new HashSet<T>(a);
        copyOfA.retainAll(b);
        _xblockexpression = copyOfA;
      }
      return _xblockexpression;
    }

    private boolean isAccessibleFrom(final MethodDeclaration method, final MutableTypeDeclaration type) {
      return ((!(Objects.equal(method.getVisibility(), org.eclipse.xtend.lib.macro.declaration.Visibility.PRIVATE) && 
        (!Objects.equal(method.getDeclaringType(), type)))) && 
        (!(Objects.equal(method.getVisibility(), org.eclipse.xtend.lib.macro.declaration.Visibility.DEFAULT) && 
          (!this.isInSamePackageAs(method, type)))));
    }

    /**
     * Determines whether `reference` is in the same package as `thiz`
     */
    private boolean isInSamePackageAs(final NamedElement thiz, final NamedElement reference) {
      String _packageName = thiz.getCompilationUnit().getPackageName();
      String _packageName_1 = reference.getCompilationUnit().getPackageName();
      return Objects.equal(_packageName, _packageName_1);
    }

    /**
     * Finds all annotations of `type` on `target`.
     * 
     * @return All annotations of type `type` on `target`.
     */
    private Iterable<? extends AnnotationReference> findAllAnnotations(final AnnotationTarget target, final Type annotationType) {
      final Function1<AnnotationReference, Boolean> _function = (AnnotationReference it) -> {
        AnnotationTypeDeclaration _annotationTypeDeclaration = it.getAnnotationTypeDeclaration();
        return Boolean.valueOf(Objects.equal(_annotationTypeDeclaration, annotationType));
      };
      return IterableExtensions.filter(target.getAnnotations(), _function);
    }

    /**
     * Determines whether `reference` can be accessed by anybody who’s able to access `thiz`.
     */
    private boolean isAsVisibleAsAs(final MethodDeclaration thiz, final MethodDeclaration reference) {
      return (this.isAsVisibleAs(reference.getDeclaringType(), thiz.getDeclaringType()) && (this.isPublic(reference) || this.isSamePackageVisible(thiz, reference)));
    }

    /**
     * Determines whether `reference` can be accessed by anybody who’s able to access `thiz`.
     */
    private boolean isAsVisibleAs(final TypeDeclaration thiz, final TypeDeclaration reference) {
      return (this.isPublic(reference) || this.isSamePackageVisible(thiz, reference));
    }

    /**
     * @return `true` iff `declaration` is public.
     */
    private boolean isPublic(final MemberDeclaration declaration) {
      org.eclipse.xtend.lib.macro.declaration.Visibility _visibility = declaration.getVisibility();
      return Objects.equal(_visibility, org.eclipse.xtend.lib.macro.declaration.Visibility.PUBLIC);
    }

    /**
     * Determines whether both `thiz` and `reference` are package-private *and* lie are the same package.
     */
    private boolean isSamePackageVisible(final MemberDeclaration thiz, final MemberDeclaration reference) {
      return ((Objects.equal(reference.getVisibility(), org.eclipse.xtend.lib.macro.declaration.Visibility.DEFAULT) && 
        Objects.equal(thiz.getVisibility(), org.eclipse.xtend.lib.macro.declaration.Visibility.DEFAULT)) && 
        this.isInSamePackageAs(reference, thiz));
    }

    /**
     * Gets the delegation targets of a {@link StaticDelegate}
     * declaration. Returns the `value` field unless it’s empty. Uses (the
     * possibly also empty) `delegationTargets` field otherwise.
     */
    private TypeReference[] delegationTargets(final AnnotationReference annotation) {
      TypeReference[] _xblockexpression = null;
      {
        final TypeReference[] value = annotation.getClassArrayValue("value");
        TypeReference[] _xifexpression = null;
        int _length = value.length;
        boolean _greaterThan = (_length > 0);
        if (_greaterThan) {
          _xifexpression = value;
        } else {
          _xifexpression = annotation.getClassArrayValue("delegationTargets");
        }
        _xblockexpression = _xifexpression;
      }
      return _xblockexpression;
    }

    /**
     * Gets the expression defining the delegation targets.
     * 
     * @return the expression that defines what {@link delegationTargets}
     * returns.
     */
    private Expression delegationTargetsExpression(final AnnotationReference annotation) {
      Expression _xblockexpression = null;
      {
        final TypeReference[] value = annotation.getClassArrayValue("value");
        Expression _xifexpression = null;
        if (((value != null) && (value.length > 0))) {
          _xifexpression = annotation.getExpression("value");
        } else {
          _xifexpression = annotation.getExpression("delegationTargets");
        }
        _xblockexpression = _xifexpression;
      }
      return _xblockexpression;
    }

    public ContexedProcessor(final TransformationContext context) {
      super();
      this.context = context;
    }
  }

  @Override
  public void doTransform(final List<? extends MutableTypeDeclaration> annotatedTargetElements, @Extension final TransformationContext context) {
    @Extension
    final ExportStaticMethodsProcessor.ContexedProcessor delegateProcessor = new ExportStaticMethodsProcessor.ContexedProcessor(context);
    for (final MutableTypeDeclaration annotatedType : annotatedTargetElements) {
      {
        final Iterable<? extends AnnotationReference> exportAnnotations = delegateProcessor.findAllAnnotations(annotatedType, context.findTypeGlobally(StaticDelegate.class));
        final ArrayList<AnnotationReference> validAnnotations = delegateProcessor.checkForSelfReference(delegateProcessor.checkForDuplicateTypes(exportAnnotations), annotatedType);
        for (final AnnotationReference exportAnnotation : validAnnotations) {
          delegateProcessor.doTransform(annotatedType, exportAnnotation);
        }
      }
    }
  }
}
