package edu.kit.ipd.sdq.activextendannotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import org.eclipse.xtend.lib.macro.Active;

/**
 * Allows to declare method parameters as resources that will be closed when
 * the method exits, no matter if it exits normally or by throwing an
 * exception. Xtend does not support Java’s try with resources, so this
 * annotation is a replacement until proper support is implemented. Instead of
 * using a {@code try} block, the resources are declared in the method
 * parameters using this extension. The method’s body will then wrapped in a
 * try with resources block.
 * 
 * <p>Annotated parameters must implements {@link AutoCloseable}.
 * 
 * <p>Methods having parameters using this annotation must declare a return
 * type due to a limitation in Xtend’s type inference system.
 * 
 * @see {@link https://bugs.eclipse.org/bugs/show_bug.cgi?id=366020}
 * @author Joshua Gleitze
 */
@Active(CloseResourceProcessor.class)
@Target(ElementType.PARAMETER)
@SuppressWarnings("all")
public @interface CloseResource {
}
