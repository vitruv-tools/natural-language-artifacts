package edu.kit.ipd.sdq.activextendannotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Target;
import org.eclipse.xtend.lib.macro.Active;

/**
 * Adds static delegate methods to all accessible static methods of the
 * declared types. This annotation can be used multiple times on the same type
 * to export methods with different visibilities.
 */
@Target(ElementType.TYPE)
@Active(ExportStaticMethodsProcessor.class)
@Repeatable(StaticDelegateContainer.class)
@SuppressWarnings("all")
public @interface StaticDelegate {
  /**
   * The types whose accessible static methods shall be delegated to.
   */
  public Class<?>[] value() default {};
  /**
   * @deprecated use {@link #value} instead
   */
  @Deprecated
  public Class<?>[] delegationTargets() default {};
  /**
   * The desired visibility of the created delegation methods.
   */
  public Visibility visibility() default Visibility.AS_DECLARED;
}
