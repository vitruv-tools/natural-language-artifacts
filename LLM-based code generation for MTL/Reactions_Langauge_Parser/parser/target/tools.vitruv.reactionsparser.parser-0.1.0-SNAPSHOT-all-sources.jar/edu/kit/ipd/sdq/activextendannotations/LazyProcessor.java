package edu.kit.ipd.sdq.activextendannotations;

import com.google.common.base.Objects;
import org.eclipse.xtend.lib.macro.AbstractFieldProcessor;
import org.eclipse.xtend.lib.macro.TransformationContext;
import org.eclipse.xtend.lib.macro.declaration.AnnotationReference;
import org.eclipse.xtend.lib.macro.declaration.FieldDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableFieldDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableMethodDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableTypeDeclaration;
import org.eclipse.xtend.lib.macro.declaration.Visibility;
import org.eclipse.xtend.lib.macro.expression.Expression;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtend2.lib.StringConcatenationClient;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class LazyProcessor extends AbstractFieldProcessor {
  @Override
  public void doTransform(final MutableFieldDeclaration field, @Extension final TransformationContext context) {
    Expression _initializer = field.getInitializer();
    boolean _tripleEquals = (_initializer == null);
    if (_tripleEquals) {
      context.addError(field, "A lazy field must have an initializer.");
      return;
    }
    Visibility _visibility = field.getVisibility();
    boolean _equals = Objects.equal(_visibility, Visibility.PUBLIC);
    if (_equals) {
      context.addWarning(field, "A lazy field should not be public, as this makes internals visible to the outside.");
    }
    MutableTypeDeclaration _declaringType = field.getDeclaringType();
    String _firstUpper = StringExtensions.toFirstUpper(field.getSimpleName());
    String _plus = ("set" + _firstUpper);
    final MutableMethodDeclaration setter = _declaringType.findDeclaredMethod(_plus, field.getType());
    if ((setter != null)) {
      context.addError(setter, "A lazy field cannot have a setter.");
    }
    final AnnotationReference annotation = field.findAnnotation(context.findTypeGlobally(Lazy.class));
    final Visibility getterVisibility = VisibilityExtension.toXtendVisibility(edu.kit.ipd.sdq.activextendannotations.Visibility.valueOf(annotation.getEnumValue("value").getSimpleName()), field.getVisibility());
    final boolean synchronizeAccess = annotation.getBooleanValue("synchronizeInitialization");
    MutableTypeDeclaration _declaringType_1 = field.getDeclaringType();
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("_");
    String _simpleName = field.getSimpleName();
    _builder.append(_simpleName);
    _builder.append("_isInitialised");
    final Procedure1<MutableFieldDeclaration> _function = (MutableFieldDeclaration it) -> {
      it.setType(context.getPrimitiveBoolean());
      StringConcatenationClient _client = new StringConcatenationClient() {
        @Override
        protected void appendTo(StringConcatenationClient.TargetStringConcatenation _builder) {
          _builder.append("false");
        }
      };
      it.setInitializer(_client);
      it.setVisibility(Visibility.PRIVATE);
      it.setStatic(field.isStatic());
      it.setVolatile((field.isVolatile() || synchronizeAccess));
      context.setPrimarySourceElement(it, field);
    };
    final MutableFieldDeclaration isInited = _declaringType_1.addField(_builder.toString(), _function);
    MutableTypeDeclaration _declaringType_2 = field.getDeclaringType();
    StringConcatenation _builder_1 = new StringConcatenation();
    _builder_1.append("_");
    String _simpleName_1 = field.getSimpleName();
    _builder_1.append(_simpleName_1);
    _builder_1.append("_initialise");
    final Procedure1<MutableMethodDeclaration> _function_1 = (MutableMethodDeclaration it) -> {
      it.setReturnType(field.getType());
      it.setStatic(field.isStatic());
      it.setVisibility(Visibility.PRIVATE);
      it.setBody(field.getInitializer());
      context.setPrimarySourceElement(it, field);
    };
    final MutableMethodDeclaration initializer = _declaringType_2.addMethod(_builder_1.toString(), _function_1);
    final Function0<CharSequence> _function_2 = () -> {
      StringConcatenation _builder_2 = new StringConcatenation();
      _builder_2.append("try {");
      _builder_2.newLine();
      _builder_2.append("\t");
      String _simpleName_2 = field.getSimpleName();
      _builder_2.append(_simpleName_2, "\t");
      _builder_2.append(" = ");
      String _simpleName_3 = initializer.getSimpleName();
      _builder_2.append(_simpleName_3, "\t");
      _builder_2.append("();");
      _builder_2.newLineIfNotEmpty();
      _builder_2.append("} finally {");
      _builder_2.newLine();
      _builder_2.append("\t");
      String _simpleName_4 = isInited.getSimpleName();
      _builder_2.append(_simpleName_4, "\t");
      _builder_2.append(" = true;");
      _builder_2.newLineIfNotEmpty();
      _builder_2.append("}");
      _builder_2.newLine();
      return _builder_2;
    };
    final Function0<CharSequence> intialization = _function_2;
    MutableTypeDeclaration _declaringType_3 = field.getDeclaringType();
    String _firstUpper_1 = StringExtensions.toFirstUpper(field.getSimpleName());
    String _plus_1 = ("get" + _firstUpper_1);
    final Procedure1<MutableMethodDeclaration> _function_3 = (MutableMethodDeclaration it) -> {
      it.setReturnType(initializer.getReturnType());
      it.setStatic(field.isStatic());
      it.setVisibility(getterVisibility);
      StringConcatenationClient _client = new StringConcatenationClient() {
        @Override
        protected void appendTo(StringConcatenationClient.TargetStringConcatenation _builder) {
          _builder.append("if (!");
          String _simpleName = isInited.getSimpleName();
          _builder.append(_simpleName);
          _builder.append(") {");
          _builder.newLineIfNotEmpty();
          {
            if (synchronizeAccess) {
              _builder.append("\t");
              _builder.append("synchronized(");
              CharSequence _initSynchronizationTarget = LazyProcessor.getInitSynchronizationTarget(field);
              _builder.append(_initSynchronizationTarget, "\t");
              _builder.append(") {");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("\t");
              _builder.append("if (!");
              String _simpleName_1 = isInited.getSimpleName();
              _builder.append(_simpleName_1, "\t\t");
              _builder.append(") {");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("\t\t");
              CharSequence _apply = intialization.apply();
              _builder.append(_apply, "\t\t\t");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("\t");
              _builder.append("}");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("}");
              _builder.newLine();
            } else {
              _builder.append("\t");
              CharSequence _apply_1 = intialization.apply();
              _builder.append(_apply_1, "\t");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("}");
          _builder.newLine();
          _builder.append("return ");
          String _simpleName_2 = field.getSimpleName();
          _builder.append(_simpleName_2);
          _builder.append(";");
          _builder.newLineIfNotEmpty();
        }
      };
      it.setBody(_client);
      context.setPrimarySourceElement(it, field);
    };
    _declaringType_3.addMethod(_plus_1, _function_3);
    final Procedure1<MutableFieldDeclaration> _function_4 = (MutableFieldDeclaration it) -> {
      it.markAsRead();
      StringConcatenation _builder_2 = new StringConcatenation();
      _builder_2.append("_");
      String _simpleName_2 = field.getSimpleName();
      _builder_2.append(_simpleName_2);
      it.setSimpleName(_builder_2.toString());
      it.setFinal(false);
      it.setVolatile((field.isVolatile() || synchronizeAccess));
      it.setVisibility(Visibility.PRIVATE);
    };
    ObjectExtensions.<MutableFieldDeclaration>operator_doubleArrow(field, _function_4);
  }

  private static CharSequence getInitSynchronizationTarget(final FieldDeclaration field) {
    CharSequence _xifexpression = null;
    boolean _isStatic = field.isStatic();
    if (_isStatic) {
      StringConcatenation _builder = new StringConcatenation();
      String _simpleName = field.getDeclaringType().getSimpleName();
      _builder.append(_simpleName);
      _builder.append(".class");
      _xifexpression = _builder;
    } else {
      _xifexpression = "this";
    }
    return _xifexpression;
  }
}
