package edu.kit.ipd.sdq.activextendannotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import org.eclipse.xtend.lib.macro.Active;

/**
 * Lazily initializes a field. A field annotated with {@code @Lazy} will get a
 * getter that will, when called for the first time in the field’s
 * lifetime, execute the field’s initializer. Subsequent calls will use the
 * computed value.
 * 
 * The generated getter will have the visibility defined in the annotation’s
 * value, which defaults to {@link Visibility.PUBLIC}. The added helpers will
 * have the visibility that’s defined on the annotated field, which allows
 * to make them visible to subtypes.
 * 
 * The initializer is guaranteed to be called at the first access and only
 * once. Should it throw a runtime exception, that exception will be thrown at
 * first access. In that case, the field will have its
 * {@link http://docs.oracle.com/javase/tutorial/java/nutsandbolts/datatypes.html default value}.
 * 
 * The variable check and call to the initializer is <em>not synchronized</em> by
 * default, which means that the implementation is not thread safe and may call the
 * initialiser multiple times when called from different threads. If you need thread
 * safety, set {@code synchronizeInitialization} to {@code true}.
 * 
 * The field itself will be renamed to have an underscore ({@code field} ->
 * {@code _field}). It should <em>never</em> be reassigned by hand, as that
 * would likely break the contract of this annotation.
 * 
 * To know whether the annotated field was already initialized,
 * {@code _field_isInitialised} can be read. Once again, the field should
 * <em>never</em> be assigned by hand as that would break this annotation’s
 * contract.
 * 
 * This annotation was inspired by
 * {@link https://github.com/eclipse/xtext-xtend/blob/master/org.eclipse.xtend.examples/projects/xtend-annotation-examples/src/lazy/Lazy.xtend
 * The Lazy annotation from Xtext’s active annotations example}
 * 
 * @author Joshua Gleitze
 */
@Target(ElementType.FIELD)
@Active(LazyProcessor.class)
@SuppressWarnings("all")
public @interface Lazy {
  public Visibility value() default Visibility.PUBLIC;
  public boolean synchronizeInitialization() default false;
}
