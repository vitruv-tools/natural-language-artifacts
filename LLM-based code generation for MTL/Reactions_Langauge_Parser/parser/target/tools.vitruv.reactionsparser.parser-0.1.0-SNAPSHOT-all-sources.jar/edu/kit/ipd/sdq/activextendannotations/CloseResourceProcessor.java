package edu.kit.ipd.sdq.activextendannotations;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import org.eclipse.xtend.lib.annotations.FinalFieldsConstructor;
import org.eclipse.xtend.lib.macro.TransformationContext;
import org.eclipse.xtend.lib.macro.TransformationParticipant;
import org.eclipse.xtend.lib.macro.ValidationContext;
import org.eclipse.xtend.lib.macro.ValidationParticipant;
import org.eclipse.xtend.lib.macro.declaration.MutableConstructorDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableExecutableDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableMethodDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableParameterDeclaration;
import org.eclipse.xtend.lib.macro.declaration.MutableTypeDeclaration;
import org.eclipse.xtend.lib.macro.declaration.ResolvedMethod;
import org.eclipse.xtend.lib.macro.declaration.TypeReference;
import org.eclipse.xtend.lib.macro.declaration.Visibility;
import org.eclipse.xtend.lib.macro.services.TypeReferenceProvider;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtend2.lib.StringConcatenationClient;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class CloseResourceProcessor implements TransformationParticipant<MutableParameterDeclaration>, ValidationParticipant<MutableParameterDeclaration> {
  @FinalFieldsConstructor
  private static class CloseResourceExecutableProcessor {
    private MutableExecutableDeclaration oldExecutable;

    private List<MutableParameterDeclaration> annotatedParameters;

    private MutableExecutableDeclaration newExecutable;

    private boolean doesReturn;

    @Extension
    private final TransformationContext context;

    @Extension
    private TypeCopier typeCopier;

    /**
     * Transforms the given {@code executable}.
     * 
     * @param executable
     * 		The executable to transform
     * @param annotatedParameters
     * 		The subset of the {@code executable}’s parameters that is
     * 		annotated with {@code TryResource}.
     */
    public void tranform(final MutableExecutableDeclaration executable, final List<MutableParameterDeclaration> annotatedParameters) {
      this.annotatedParameters = annotatedParameters;
      final MutableTypeDeclaration type = executable.getDeclaringType();
      boolean _matched = false;
      if (executable instanceof MutableMethodDeclaration) {
        _matched=true;
        boolean _isInferred = ((MutableMethodDeclaration)executable).getReturnType().isInferred();
        if (_isInferred) {
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("A method using @");
          String _simpleName = CloseResource.class.getSimpleName();
          _builder.append(_simpleName);
          _builder.append(" must declare its return type");
          this.context.addError(executable, _builder.toString());
          return;
        }
        StringConcatenation _builder_1 = new StringConcatenation();
        _builder_1.append("_");
        String _simpleName_1 = ((MutableMethodDeclaration)executable).getSimpleName();
        _builder_1.append(_simpleName_1);
        _builder_1.append("_with_safe_resources");
        final Procedure1<MutableMethodDeclaration> _function = (MutableMethodDeclaration it) -> {
        };
        final MutableMethodDeclaration newMethod = type.addMethod(_builder_1.toString(), _function);
        this.withMethod(newMethod, ((MutableMethodDeclaration)executable));
      }
      if (!_matched) {
        if (executable instanceof MutableConstructorDeclaration) {
          _matched=true;
          final Procedure1<MutableConstructorDeclaration> _function = (MutableConstructorDeclaration it) -> {
          };
          final MutableConstructorDeclaration newConstructor = type.addConstructor(_function);
          this.withConstructor(newConstructor, ((MutableConstructorDeclaration)executable));
        }
      }
      if (!_matched) {
        throw new AssertionError("Unknown subclass of MutableExecutableDeclration");
      }
      this.transform();
    }

    public MutableExecutableDeclaration withMethod(final MutableMethodDeclaration newMethod, final MutableMethodDeclaration oldMethod) {
      MutableExecutableDeclaration _xblockexpression = null;
      {
        TypeCopier _typeCopier = new TypeCopier(this.context);
        this.typeCopier = _typeCopier;
        final Procedure1<MutableMethodDeclaration> _function = (MutableMethodDeclaration it) -> {
          this.typeCopier.copyTypeParametersFrom(it, oldMethod);
          this.context.setPrimarySourceElement(it, oldMethod);
          it.setStatic(oldMethod.isStatic());
          it.setFinal(oldMethod.isFinal());
          it.setReturnType(this.typeCopier.replaceTypeParameters(oldMethod.getReturnType()));
        };
        ObjectExtensions.<MutableMethodDeclaration>operator_doubleArrow(newMethod, _function);
        boolean _isVoid = oldMethod.getReturnType().isVoid();
        boolean _not = (!_isVoid);
        this.doesReturn = _not;
        this.newExecutable = newMethod;
        _xblockexpression = this.oldExecutable = oldMethod;
      }
      return _xblockexpression;
    }

    public boolean withConstructor(final MutableConstructorDeclaration constructor, final MutableConstructorDeclaration oldConstructor) {
      boolean _xblockexpression = false;
      {
        TypeCopier _typeCopier = new TypeCopier(this.context);
        this.typeCopier = _typeCopier;
        final Procedure1<MutableConstructorDeclaration> _function = (MutableConstructorDeclaration it) -> {
          this.context.setPrimarySourceElement(it, oldConstructor);
        };
        ObjectExtensions.<MutableConstructorDeclaration>operator_doubleArrow(constructor, _function);
        this.newExecutable = constructor;
        this.oldExecutable = oldConstructor;
        _xblockexpression = this.doesReturn = false;
      }
      return _xblockexpression;
    }

    public void transform() {
      @Extension
      final CloseResourceProcessor.TypeInfo info = new CloseResourceProcessor.TypeInfo(this.context);
      final Procedure1<MutableExecutableDeclaration> _function = (MutableExecutableDeclaration it) -> {
        it.setVisibility(Visibility.PRIVATE);
        it.setBody(this.oldExecutable.getBody());
        it.setDocComment(this.oldExecutable.getDocComment());
        it.setVarArgs(this.oldExecutable.isVarArgs());
        final Function1<TypeReference, TypeReference> _function_1 = (TypeReference it_1) -> {
          return this.typeCopier.replaceTypeParameters(it_1);
        };
        it.setExceptions(((TypeReference[])Conversions.unwrapArray(IterableExtensions.map(this.oldExecutable.getExceptions(), _function_1), TypeReference.class)));
      };
      ObjectExtensions.<MutableExecutableDeclaration>operator_doubleArrow(
        this.newExecutable, _function);
      final Consumer<MutableParameterDeclaration> _function_1 = (MutableParameterDeclaration it) -> {
        this.newExecutable.addParameter(it.getSimpleName(), this.typeCopier.replaceTypeParameters(it.getType()));
      };
      this.oldExecutable.getParameters().forEach(_function_1);
      final Function1<MutableParameterDeclaration, Set<? extends TypeReference>> _function_2 = (MutableParameterDeclaration it) -> {
        return info.withAllSuperTypes(it.getType());
      };
      final Function1<Set<? extends TypeReference>, ResolvedMethod> _function_3 = (Set<? extends TypeReference> it) -> {
        final Function1<TypeReference, ResolvedMethod> _function_4 = (TypeReference it_1) -> {
          final Function1<ResolvedMethod, Boolean> _function_5 = (ResolvedMethod it_2) -> {
            String _simpleSignature = it_2.getSimpleSignature();
            return Boolean.valueOf(Objects.equal(_simpleSignature, "close()"));
          };
          return IterableExtensions.<ResolvedMethod>findFirst(Iterables.<ResolvedMethod>filter(it_1.getDeclaredResolvedMethods(), ResolvedMethod.class), _function_5);
        };
        final Function1<ResolvedMethod, Boolean> _function_5 = (ResolvedMethod it_1) -> {
          return Boolean.valueOf((it_1 != null));
        };
        return IterableExtensions.<ResolvedMethod>findFirst(IterableExtensions.map(it, _function_4), _function_5);
      };
      final Function1<ResolvedMethod, Boolean> _function_4 = (ResolvedMethod it) -> {
        return Boolean.valueOf((it != null));
      };
      final Function1<ResolvedMethod, Iterable<? extends TypeReference>> _function_5 = (ResolvedMethod it) -> {
        return it.getResolvedExceptionTypes();
      };
      final Iterable<TypeReference> closeExceptions = Iterables.<TypeReference>concat(IterableExtensions.<ResolvedMethod, Iterable<? extends TypeReference>>map(IterableExtensions.<ResolvedMethod>filter(ListExtensions.<Set<? extends TypeReference>, ResolvedMethod>map(ListExtensions.<MutableParameterDeclaration, Set<? extends TypeReference>>map(this.annotatedParameters, _function_2), _function_3), _function_4), _function_5));
      Iterable<? extends TypeReference> _exceptions = this.oldExecutable.getExceptions();
      this.oldExecutable.setExceptions(((TypeReference[])Conversions.unwrapArray(IterableExtensions.<TypeReference>toSet(Iterables.<TypeReference>concat(_exceptions, closeExceptions)), TypeReference.class)));
      StringConcatenationClient _client = new StringConcatenationClient() {
        @Override
        protected void appendTo(StringConcatenationClient.TargetStringConcatenation _builder) {
          _builder.append("try (");
          {
            boolean _hasElements = false;
            for(final MutableParameterDeclaration p : CloseResourceExecutableProcessor.this.annotatedParameters) {
              if (!_hasElements) {
                _hasElements = true;
              } else {
                _builder.appendImmediate("; ", "");
              }
              TypeReference _type = p.getType();
              _builder.append(_type);
              _builder.append(" r_");
              String _simpleName = p.getSimpleName();
              _builder.append(_simpleName);
              _builder.append(" = ");
              String _simpleName_1 = p.getSimpleName();
              _builder.append(_simpleName_1);
            }
          }
          _builder.append(") {");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          {
            if (CloseResourceExecutableProcessor.this.doesReturn) {
              _builder.append("return ");
            }
          }
          String _simpleName_2 = CloseResourceExecutableProcessor.this.newExecutable.getSimpleName();
          _builder.append(_simpleName_2, "\t");
          _builder.append("(");
          {
            Iterable<? extends MutableParameterDeclaration> _parameters = CloseResourceExecutableProcessor.this.oldExecutable.getParameters();
            boolean _hasElements_1 = false;
            for(final MutableParameterDeclaration p_1 : _parameters) {
              if (!_hasElements_1) {
                _hasElements_1 = true;
              } else {
                _builder.appendImmediate(", ", "\t");
              }
              {
                boolean _isAnnotated = CloseResourceExecutableProcessor.this.isAnnotated(p_1);
                if (_isAnnotated) {
                  _builder.append("r_");
                }
              }
              String _simpleName_3 = p_1.getSimpleName();
              _builder.append(_simpleName_3, "\t");
            }
          }
          _builder.append(");");
          _builder.newLineIfNotEmpty();
          _builder.append("}\t\t\t");
          _builder.newLine();
        }
      };
      this.oldExecutable.setBody(_client);
      this.oldExecutable.setDocComment("");
    }

    public boolean isAnnotated(final MutableParameterDeclaration parameter) {
      return this.annotatedParameters.contains(parameter);
    }

    public CloseResourceExecutableProcessor(final TransformationContext context) {
      super();
      this.context = context;
    }
  }

  @FinalFieldsConstructor
  private static class TypeInfo {
    @Extension
    private final TypeReferenceProvider provider;

    /**
     * Checks whether the provided {@code typeReference} implements or
     * extends the provided {@code superType}.
     * 
     * @param typeReference
     * 		A type reference.
     * @param superType
     * 		The type to look for.
     * @return {@code true} iff {@code typeReference} or any of its super
     *  types is {@code superType}.
     */
    private boolean hasSuperType(final TypeReference typeReference, final Class<?> superType) {
      return this.withAllSuperTypes(typeReference).contains(this.provider.newTypeReference(superType));
    }

    private Set<? extends TypeReference> withAllSuperTypes(final TypeReference typeReference) {
      final Function1<TypeReference, Set<? extends TypeReference>> _function = (TypeReference it) -> {
        return this.withAllSuperTypes(it);
      };
      Iterable<TypeReference> _flatten = Iterables.<TypeReference>concat(IterableExtensions.map(typeReference.getDeclaredSuperTypes(), _function));
      return IterableExtensions.<TypeReference>toSet(Iterables.<TypeReference>concat(Collections.<TypeReference>unmodifiableList(CollectionLiterals.<TypeReference>newArrayList(typeReference)), _flatten));
    }

    public TypeInfo(final TypeReferenceProvider provider) {
      super();
      this.provider = provider;
    }
  }

  @Override
  public void doTransform(final List<? extends MutableParameterDeclaration> annotatedTargetElements, @Extension final TransformationContext context) {
    final Function1<MutableParameterDeclaration, MutableExecutableDeclaration> _function = (MutableParameterDeclaration it) -> {
      return it.getDeclaringExecutable();
    };
    final Map<MutableExecutableDeclaration, List<MutableParameterDeclaration>> grouped = IterableExtensions.<MutableExecutableDeclaration, MutableParameterDeclaration>groupBy(annotatedTargetElements, _function);
    Set<Map.Entry<MutableExecutableDeclaration, List<MutableParameterDeclaration>>> _entrySet = grouped.entrySet();
    for (final Map.Entry<MutableExecutableDeclaration, List<MutableParameterDeclaration>> annotationEntry : _entrySet) {
      new CloseResourceProcessor.CloseResourceExecutableProcessor(context).tranform(annotationEntry.getKey(), annotationEntry.getValue());
    }
  }

  @Override
  public void doValidate(final List<? extends MutableParameterDeclaration> annotatedTargetElements, @Extension final ValidationContext context) {
    @Extension
    final CloseResourceProcessor.TypeInfo info = new CloseResourceProcessor.TypeInfo(context);
    for (final MutableParameterDeclaration parameter : annotatedTargetElements) {
      boolean _hasSuperType = info.hasSuperType(parameter.getType(), AutoCloseable.class);
      boolean _not = (!_hasSuperType);
      if (_not) {
        context.addError(parameter, "A resource for try-with-resources must implement AutoCloseable!");
      }
    }
  }
}
